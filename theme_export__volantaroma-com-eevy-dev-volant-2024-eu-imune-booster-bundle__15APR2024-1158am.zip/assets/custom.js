/**
 * DEVELOPER DOCUMENTATION
 *
 * Include your custom JavaScript here.
 *
 * The theme Focal has been developed to be easily extensible through the usage of a lot of different JavaScript
 * events, as well as the usage of custom elements (https://developers.google.com/web/fundamentals/web-components/customelements)
 * to easily extend the theme and re-use the theme infrastructure for your own code.
 *
 * The technical documentation is summarized here.
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A VARIANT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a the user has changed the variant in a selector. The target get you the form
 * that triggered this event.
 *
 * Example:
 *
 * document.addEventListener('variant:changed', function(event) {
 *   let variant = event.detail.variant; // Gives you access to the whole variant details
 *   let form = event.target;
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * MANUALLY CHANGE A VARIANT
 * ------------------------------------------------------------------------------------------------------------
 *
 * You may want to manually change the variant, and let the theme automatically adjust all the selectors. To do
 * that, you can get the DOM element of type "<product-variants>", and call the selectVariant method on it with
 * the variant ID.
 *
 * Example:
 *
 * const productVariantElement = document.querySelector('product-variants');
 * productVariantElement.selectVariant(12345);
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A NEW VARIANT IS ADDED TO THE CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a variant is added to the cart through a form selector (product page, quick
 * view...). This event DOES NOT include any change done through the cart on an existing variant. For that,
 * please refer to the "cart:updated" event.
 *
 * Example:
 *
 * document.addEventListener('variant:added', function(event) {
 *   var variant = event.detail.variant; // Get the variant that was added
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN THE CART CONTENT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever the cart content has changed (if the quantity of a variant has changed, if a variant
 * has been removed, if the note has changed...). This event will also be emitted when a new variant has been
 * added (so you will receive both "variant:added" and "cart:updated"). Contrary to the variant:added event,
 * this event will give you the complete details of the cart.
 *
 * Example:
 *
 * document.addEventListener('cart:updated', function(event) {
 *   var cart = event.detail.cart; // Get the updated content of the cart
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * REFRESH THE CART/MINI-CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * If you are adding variants to the cart and would like to instruct the theme to re-render the cart, you cart
 * send the cart:refresh event, as shown below:
 *
 * document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
 *   bubbles: true
 * }));
 *
 * ------------------------------------------------------------------------------------------------------------
 * USAGE OF CUSTOM ELEMENTS
 * ------------------------------------------------------------------------------------------------------------
 *
 * Our theme makes extensive use of HTML custom elements. Custom elements are an awesome way to extend HTML
 * by creating new elements that carry their own JavaScript for adding new behavior. The theme uses a large
 * number of custom elements, but the two most useful are drawer and popover. Each of those components add
 * a "open" attribute that you can toggle on and off. For instance, let's say you would like to open the cart
 * drawer, whose id is "mini-cart", you simply need to retrieve it and set its "open" attribute to true (or
 * false to close it):
 *
 * document.getElementById('mini-cart').open = true;
 *
 * Thanks to the power of custom elements, the theme will take care automagically of trapping focus, maintaining
 * proper accessibility attributes...
 *
 * If you would like to create your own drawer, you can re-use the <drawer-content> content. Here is a simple
 * example:
 *
 * // Make sure you add "aria-controls", "aria-expanded" and "is" HTML attributes to your button:
 * <button type="button" is="toggle-button" aria-controls="id-of-drawer" aria-expanded="false">Open drawer</button>
 *
 * <drawer-content id="id-of-drawer">
 *   Your content
 * </drawer-content>
 *
 * The nice thing with custom elements is that you do not actually need to instantiate JavaScript yourself: this
 * is done automatically as soon as the element is inserted to the DOM.
 *
 * ------------------------------------------------------------------------------------------------------------
 * THEME DEPENDENCIES
 * ------------------------------------------------------------------------------------------------------------
 *
 * While the theme tries to keep outside dependencies as small as possible, the theme still uses third-party code
 * to power some of its features. Here is the list of all dependencies:
 *
 * "vendor.js":
 *
 * The vendor.js contains required dependencies. This file is loaded in parallel of the theme file.
 *
 * - custom-elements polyfill (used for built-in elements on Safari - v1.0.0): https://github.com/ungap/custom-elements
 * - web-animations-polyfill (used for polyfilling WebAnimations on Safari 12, this polyfill will be removed in 1 year - v2.3.2): https://github.com/web-animations/web-animations-js
 * - instant-page (v5.1.0): https://github.com/instantpage/instant.page
 * - tocca (v2.0.9); https://github.com/GianlucaGuarini/Tocca.js/
 * - seamless-scroll-polyfill (v2.0.0): https://github.com/magic-akari/seamless-scroll-polyfill
 *
 * "flickity.js": v2.2.0 (with the "fade" package). Flickity is only loaded on demand if there is a product image
 * carousel on the page. Otherwise it is not loaded.
 *
 * "photoswipe": v4.1.3. PhotoSwipe is only loaded on demand to power the zoom feature on product page. If the zoom
 * feature is disabled, then this script is never loaded.
 */



 $('.filter-item:not(.filter-sort) .filter-title').click(function() {
    $(this).parent('.filter-item').toggleClass('opened');
    $(this).siblings('.filter-list, .filter-list-alt').slideToggle();
  });
  
  $('.more-filters').click(function() {
    $(this).prev('.more-filters-list').toggleClass('expand').slideToggle();
    if ($(this).prev('.more-filters-list').hasClass('expand')) {
      $(this).html('Less ' + $(this).data('option'));
    } else {
      $(this).html('More ' + $(this).data('option'));
    }
  });
  
  $('div.filter:not(.sort)').click(function() {
    var type = $(this).data('type'),
        category = $(this).data('category'),
        value = $(this).data('value'),
        title = $(this).children('span').first().text();
    
    if($(this).hasClass('selected')) {
      $(this).removeClass('selected');
  
      if(type === 'checkbox') {
        var $checkbox = $(this).find('input.checkbox');
        $checkbox.prop("checked", false);
      }
      $(`span.filter[data-value="${value}"]`).remove();
      if($('div.filter.selected').length === 0) clearFilters();
    } else {
      if(type === 'checkbox') {
        var $checkbox = $(this).find('input.checkbox');
        $checkbox.prop("checked", true);
      } else if(type === 'radio') { 
        $(`div.filter[data-category="${category}"]`).removeClass('selected');
      }
      $(this).addClass('selected');
      addFilterToSelected(value, category, type, title);
    }
  
    filterProducts();
  });
  
  $('div.filter.sort').click(function() { 
    var value = $(this).data('value');
    if($(this).hasClass('selected')) {
      $(this).removeClass('selected');
    } else {
      $('div.filter.sort').removeClass('selected');
      $(this).addClass('selected');
    }
  });
  
  $('.selected-filters').on('click', '.close-filter', function() {
    var parent = $(this).parent('.filter'),
        value = parent.data('value');
  
    parent.remove();
    $(`div.filter[data-value="${value}"]`).removeClass('selected open');
    if (parent.data('category') == 'ingredients') {
      $(`div.filter[data-value="${value}"]`).find('input[type="checkbox"]').prop('checked', false);
    }
    if($('div.filter.selected').length === 0) {
      clearFilters();
    } else {
      filterProducts();
    }
  });
  
  $('#clear-all-filters, #clear-all-filters-xs').click(() => {
    clearFilters();
    $('body').removeClass('scroll-disabled');
    $('div.option-wrapper').removeClass('hovered selected');
    $('.mobile-filters-total').text($('.mobile-filters-total').data('collection-products'));
  });
  
  function addFilterToSelected(value, category, type, title) {
    var filterWrapper = '', 
        categoryFilter = $(`span.filter[data-category="${category}"]`);
    
    filterWrapper = document.getElementById('filter-display');
  
    if(categoryFilter.length && type === 'radio') { 
      var value = categoryFilter[0].dataset.value;
      $(`span.filter[data-value="${value}"]`).remove();
      //$(`div.filter[data-value="${value}"]`).removeClass('selected');
    }
  
    filterWrapper.innerHTML += ` <span class="filter" data-value="${value}" data-category="${category}">
        ${title} <img class="close-filter" src="https://cdn.shopify.com/s/files/1/0535/9088/4510/files/x.svg?v=1627733300"></span>
    `;
  
    $('.selected-filters').css('display','inline-block');
  }
  
  $('#filter-clicker').click(() => {
    filterProducts();
  });
  
  function filterProducts() {
    $('product-item').hide();
    var $selectedFilters = $('div.filter.selected'),
        $selectedSort = $('div.filter.sort.selected'),
        $products = $('.product-item'),
        totalMatched = 0,
        isPrice = false;
    
    if($selectedFilters.length === 0) {
    //if($selectedFilters.length === 0 || ($selectedFilters.length === 1 && $selectedSort.length == 1)) {
      clearFilters();
    } else {
      if($(window).width() > 768) {
        $('html, body').stop().animate({
            'scrollTop': $('.product-facet__product-list').offset().top - 210
        }, 500, 'swing');
      }
  
      var IngredientsArr = [];
      $products.each((ii, product) => { 
        var productFilters = product.dataset.filters.toLowerCase(),
            productPrice = product.dataset.price,
            isMatched = true;
  
        productFilters = replaceAll(productFilters,' ','-');
        
        $selectedFilters.each((i, filter) => { 
          var filterValue = replaceAll(filter.dataset.value,' ','-'),
              filterCategory = filter.dataset.category;
 
            
          
          if(typeof filterCategory !== 'undefined' && filterCategory === 'ingredients') { 
              var productTags = productFilters.split('|');
            
              var intersection = productTags.filter(filterValue => IngredientsArr.includes(filterValue));
   
              if (intersection.length <= 0) isMatched = false; 

            console.log(isMatched)
            
          } else if(typeof filterCategory !== 'undefined' && filterCategory !== 'price') {
            if(!productFilters.includes(filterValue)) isMatched = false;
          }
        });
        $selectedFilters.each((i, filter) => {
          var filterValue = filter.dataset.value,
              filterCategory = filter.dataset.category;
  
          if(typeof filterCategory !== 'undefined' && filterCategory == 'ingredients') {
            if(productFilters.includes(filterValue)) isMatched = true;
          }
        });
        if($('div.filter.selected[data-category="price"]').length) {
          // if Filter is not selected
          if(!$('div.filter[data-value="0-50"]').hasClass('selected')) {
            if(productPrice <5000) {
              isMatched = false;
            }
          }
          if(!$('div.filter[data-value="50-100"]').hasClass('selected')) {
            if(productPrice > 4999 && productPrice <10000) {
              isMatched = false;
            }
          }
          if(!$('div.filter[data-value="100-150"]').hasClass('selected')) {
            if(productPrice > 9999 && productPrice <15000) {
              isMatched = false;
            }
          }
          if(!$('div.filter[data-value="150+"]').hasClass('selected')) {
            if(productPrice > 14999) {
              isMatched = false;
            }
          }
        }
        if($('div.filter.bf-price.selected').length) {
          if(productPrice <5001) {
            isMatched = true;
          }
        }
        if(isMatched) {
          product.style.display = 'block';
          totalMatched++;
        }
      });
      $('.mobile-filters-total').text(totalMatched);
      if (totalMatched == 0) {
        $('.no-results').removeClass('hide');
      } else {
        $('.no-results').addClass('hide');
      }
    }
  }
  
  function clearFilters() { 
    $('.selected-filters').hide();
    $('span.filter').remove();
    $('div.filter:not(.sort)').removeClass('selected');
    $('input.checkbox').prop("checked", false);
    $('product-item').show();
    $('.mobile-filters-total').text($('.mobile-filters-total').data('collection-products'));
  }
  
  function replaceAll(string, search, replace) {
    return string.split(search).join(replace);
  }
  
  const capitalize = (str, lower = false) =>
    (lower ? str.toLowerCase() : str).replace(/(?:^|\s|["'([{])+\S/g, match => match.toUpperCase());
  
  $(document).on('click', '.open-filter, [aria-controls="facet-filters"]', function() {
    $('.filter-column').addClass('open');
    $('body').addClass('overflow-hidden');
    $('.filter-column').removeClass('popup-sort');
  });
  $(document).on('click', '.close-filter', function() {
    $('.filter-column').removeClass('open');
    $('body').removeClass('overflow-hidden');
  });
$(document).ready(function(){
  $('.mobile-toolbar__item--sort').on('click',function(){
    $('.filter-column').addClass('open popup-sort');
    $('.popover').toggleClass('popup-active');
  });
  $('.popover__close-button,.popover__overlay').on('click',function(){
    $('.filter-column').removeClass('open popup-sort'); 
  });

  $(document).on('click', '.language-selector .current-language', function(e) {
  e.preventDefault();
  $('[data-type="country-switcher"]').trigger('click');
});

$(document).ready(function() { 
  var current_locale = $('html').attr('lang');
  if (current_locale == 'en') {
    current_locale = "us";
  }
  var title = $('.language-selector ul li.language.flag-' + current_locale).find('a').attr('aria-label');
  var currency = $('.language-selector ul li.language.flag-' + current_locale).find('.currency').clone();
  $('.current-language').html('<span class="language flag-'+ current_locale +'"><a href="#">'+ title +' '+ $(currency).html() +'</a></span>');
  $('.language-selector ul li.language.flag-' + current_locale).remove();

     var colNamex = $('.product-template .color-swatch__radio:checked ').val().toLowerCase();;
     $('.descrip').hide();
     $('.descrip.'+colNamex).show();
  
  $('.color-swatch  label').on('click',function(){
     var colName = $(this).parent().find('input').val().toLowerCase();;
     $('.descrip').hide();
     $('.descrip.'+colName).show();
  });
  var colNamex = $('.product-template .color-swatch__radio:checked ').val().toLowerCase();;
     $('.detai').hide();
     $('.detai.'+colNamex).show();
  
  $('.color-swatch  label').on('click',function(){
     var colName = $(this).parent().find('input').val().toLowerCase();;
     $('.detai').hide();
     $('.detai.'+colName).show();
  });
  var colNamex = $('.product-template .color-swatch__radio:checked ').val().toLowerCase();;
     $('.scent').hide();
     $('.scent.'+colNamex).show();
  
  $('.color-swatch  label').on('click',function(){
     var colName = $(this).parent().find('input').val().toLowerCase();;
     $('.scent').hide();
     $('.scent.'+colName).show();
  });
});


/* Black Sale Week Countdown */
if ($('body').hasClass('template-collection')) {
            
  function convertTimezone(date, timezoneString) {
      return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {timeZone: timezoneString}));
  }

  if (show_timer == true && $.trim(timer) != '') {
      var convertedDate = convertTimezone(timer + " +0100", Intl.DateTimeFormat().resolvedOptions().timeZone);
      var convertedDateString =
      convertedDate.getFullYear() + "/" +
      ("00" + (convertedDate.getMonth() + 1)).slice(-2) + "/" +
      ("00" + convertedDate.getDate()).slice(-2) + " " +
      ("00" + convertedDate.getHours()).slice(-2) + ":" +
      ("00" + convertedDate.getMinutes()).slice(-2) + ":" +
      ("00" + convertedDate.getSeconds()).slice(-2);
      
      $('#countdown-time').countdown(convertedDateString.toString(), function(event) {
          var czas = event.strftime('%D|%H|%M|%S');
          var result = czas.split('|');
          
          var day = result['0'];
          $('.day-digit-1').html(day['0']);
          $('.day-digit-2').html(day['1']);

          var hour = result['1'];
          $('.hour-digit-1').html(hour['0']);
          $('.hour-digit-2').html(hour['1']);

          var mintues = result['2'];
          $('.mintues-digit-1').html(mintues['0']);
          $('.mintues-digit-2').html(mintues['1']);

          var seconds = result['3'];
          $('.seconds-digit-1').html(seconds['0']);
          $('.seconds-digit-2').html(seconds['1']);
      });
  }
}

  
});


setTimeout(function() {
  document.querySelectorAll('.rc-radio').forEach(radio => {
    console.log('click');
    radio.addEventListener('click', event => {

      var radiocontainer = event.target.closest('.rc-radio');
      var radio = radiocontainer.querySelector('.rc-radio__input')
      // if(radio.value == 'subscription'){
      //   // console.log('subscription');
      // }
      var pricontainers = document.querySelectorAll('[data-product-price-list] .price');
      pricontainers.forEach(pricontainer => {      
        pricontainer.innerHTML = radiocontainer.querySelector('.price-label').innerHTML;
      });
    });
  });
}, 3500);

$(document).on('click', 'a[href^="#"]', function (event) {
    event.preventDefault();

    $('html, body').animate({
        scrollTop: $($.attr(this, 'href')).offset().top
    }, 300);
});